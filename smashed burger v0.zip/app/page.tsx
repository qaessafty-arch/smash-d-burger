'use client'

import { useEffect, useState } from 'react'
import { LocationMap } from '@/components/location-map'
import {
  ArrowUpRight,
  ChevronDown,
  Clock3,
  Flame,
  MapPin,
  Menu as MenuIcon,
  MessageCircle,
  Plus,
  Star,
  X,
  Zap,
} from 'lucide-react'

const wa = 'https://wa.me/9647500000000?text=Hi%20Smashed%20Burger%2C%20I%27d%20like%20to%20order.'
const heroBackgrounds = [
  'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smashed%20burger%20infront-Lq3QmBR7UEDrDRqgNW2WneUum382sA.jpg',
  'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/smashed%20burger1-uwhgxZoQxNwLcddFXz9vn4cUx8qBH7.jpg',
]

const featured = [
  { name: 'Classic Smash', desc: 'American cheese, pickles, house sauce.', price: '8,000', image: '/smashed-burger-menu.png', tag: 'Bestseller' },
  { name: 'Double Cheese', desc: 'Two patties, double cheese, onion jam.', price: '12,000', image: '/smashed-burger-hero.png', tag: 'Most loved' },
  { name: 'Spicy Erbil', desc: 'Jalapeño, spicy mayo, crispy onions.', price: '10,000', image: '/smashed-burger-menu.png', tag: 'Hot one' },
  { name: 'Chicken Smash', desc: 'Crispy chicken, lettuce, garlic sauce.', price: '9,000', image: '/smashed-burger-hero.png', tag: 'New' },
]

const menu = {
  Burgers: [
    ['Classic Smash', 'Single beef patty, American cheese, pickles, house sauce.', '8,000', 'POPULAR'],
    ['Double Cheese Smash', 'Two smashed patties, double cheese, caramelized onions.', '12,000', 'SIGNATURE'],
    ['Spicy Erbil Smash', 'Beef patty, jalapeños, spicy mayo, crispy onions.', '10,000', 'SPICY'],
    ['Chicken Smash', 'Crispy chicken, lettuce, garlic sauce.', '9,000', 'NEW'],
  ],
  Sides: [['Fries', 'Crispy, golden and salted to order.', '3,000', ''], ['Loaded Fries', 'Cheese sauce, crispy onions and house sauce.', '6,000', 'POPULAR'], ['Onion Rings', 'Crispy beer-battered onion rings.', '4,000', '']],
  Drinks: [['Soft Drink', 'Ice-cold classic.', '2,000', ''], ['Milkshake', 'Thick, creamy and made to order.', '5,000', 'POPULAR'], ['Water', 'Still mineral water.', '1,000', '']],
  Combos: [['Classic Combo', 'Classic burger + fries + drink.', '11,000', 'BEST VALUE'], ['Double Combo', 'Double burger + fries + drink.', '15,000', 'BEST VALUE']],
}

const copy = {
  EN: { order: 'Order now', menu: 'View menu', home: 'Home', about: 'About', reviews: 'Reviews', contact: 'Contact' },
  KU: { order: 'داواکاری بکە', menu: 'مێنیو ببینە', home: 'ماڵەوە', about: 'دەربارە', reviews: 'هەڵسەنگاندن', contact: 'پەیوەندی' },
  AR: { order: 'اطلب الآن', menu: 'شاهد القائمة', home: 'الرئيسية', about: 'قصتنا', reviews: 'التقييمات', contact: 'اتصل بنا' },
}

export default function Page() {
  const [lang, setLang] = useState<'EN' | 'KU' | 'AR'>('EN')
  const [mobileOpen, setMobileOpen] = useState(false)
  const [category, setCategory] = useState<keyof typeof menu>('Burgers')
  const [cart, setCart] = useState(0)
  const [heroBackground, setHeroBackground] = useState(0)
  const t = copy[lang]

  useEffect(() => {
    const timer = window.setInterval(() => {
      setHeroBackground((current) => (current + 1) % heroBackgrounds.length)
    }, 6500)
    return () => window.clearInterval(timer)
  }, [])
  const rtl = lang !== 'EN'

  return (
    <div dir={rtl ? 'rtl' : 'ltr'} className="site-shell">
      <header className="nav-wrap">
        <nav className="nav container" aria-label="Main navigation">
          <a href="#home" className="brand" aria-label="Smashed Burger home"><span className="brand-mark"><Flame size={19} fill="currentColor" /></span><span>SMASHED<br /><b>BURGER</b></span></a>
          <div className="nav-links"><a href="#home">{t.home}</a><a href="#menu">Menu</a><a href="#about">{t.about}</a><a href="#reviews">{t.reviews}</a><a href="#contact">{t.contact}</a></div>
          <div className="nav-actions"><div className="languages">{(['EN', 'KU', 'AR'] as const).map((item) => <button key={item} onClick={() => setLang(item)} className={lang === item ? 'active' : ''}>{item}</button>)}</div><a className="button button-orange desktop-order" href={wa}>{t.order}<ArrowUpRight size={16} /></a><button className="mobile-toggle" aria-label="Toggle menu" onClick={() => setMobileOpen(!mobileOpen)}>{mobileOpen ? <X /> : <MenuIcon />}</button></div>
        </nav>
        {mobileOpen && <div className="mobile-menu"><a href="#home" onClick={() => setMobileOpen(false)}>{t.home}</a><a href="#menu" onClick={() => setMobileOpen(false)}>Menu</a><a href="#about" onClick={() => setMobileOpen(false)}>{t.about}</a><a href="#reviews" onClick={() => setMobileOpen(false)}>{t.reviews}</a><a href="#contact" onClick={() => setMobileOpen(false)}>{t.contact}</a><a className="button button-orange" href={wa}>{t.order} <ArrowUpRight size={16} /></a></div>}
      </header>

      <main>
        <section id="home" className="hero"><div className="hero-image" style={{ backgroundImage: `linear-gradient(90deg, #101010 0%, #101010d9 35%, #10101055 70%, #10101022), url("${heroBackgrounds[heroBackground]}")` }} aria-hidden="true" /><div className="hero-content container"><p className="eyebrow"><span /> ERBIL · KURDISTAN <span /></p><h1>ERBIL&apos;S<br /><em>BOLDEST</em><br />SMASH BURGER</h1><p className="hero-copy">Fresh beef smashed on a screaming-hot grill. Crispy edges. Oozing cheese. In your hands in 5 minutes.</p><div className="hero-buttons"><a className="button button-orange" href={wa}>{t.order} <ArrowUpRight size={17} /></a><a className="button button-outline" href="#menu">{t.menu} <ChevronDown size={17} /></a></div><div className="trust-row"><span><Star size={15} fill="currentColor" /> <b>4.9</b> <small>500+ reviews</small></span><span><Zap size={15} fill="currentColor" /> <b>30 min</b> <small>delivery</small></span><span><span className="beef-dot" /> <b>100%</b> <small>fresh beef</small></span></div></div><div className="hero-sticker">SMASH<br /><span>IT</span><br />HOT</div></section>

        <section className="ticker"><div>FRESH DAILY <span>✦</span> SMASHED TO ORDER <span>✦</span> ERBIL&apos;S FAVOURITE <span>✦</span> FRESH DAILY <span>✦</span> SMASHED TO ORDER <span>✦</span></div></section>

        <section className="developer-panel"><div className="container dev-panel-grid"><div><p className="eyebrow dark">THE SMASHED SYSTEM</p><h2>BUILT LIKE A<br /><span>GOOD PRODUCT.</span></h2><p className="dev-copy">A small-batch burger workflow with a big-screen attitude. Every layer is intentional: crisp edges, warm bread, sharp contrast and zero wasted motion.</p></div><div className="dev-specs"><div><span>01 / INPUT</span><strong>100% local beef</strong></div><div><span>02 / PROCESS</span><strong>Cast-iron smash</strong></div><div><span>03 / OUTPUT</span><strong>Hot in 5 minutes</strong></div><div><span>STATUS</span><strong className="status-live"><i /> GRILL ONLINE</strong></div></div></div></section>

        <section id="menu" className="menu-backdrop">
          <div className="section container"><div className="section-head"><div><p className="eyebrow dark">THE GOOD STUFF</p><h2>BUILT FOR<br /><span>BIG CRAVINGS.</span></h2></div><a href="#full-menu" className="text-link">See full menu <ArrowUpRight size={17} /></a></div><div className="featured-grid">{featured.map((item) => <article className="food-card" key={item.name}><div className="food-img"><img src={item.image} alt={`${item.name} smash burger`} /><span>{item.tag}</span></div><div className="food-info"><div><h3>{item.name}</h3><p>{item.desc}</p></div><div className="price-row"><strong>{item.price} <small>IQD</small></strong><button className="add-button" aria-label={`Add ${item.name}`} onClick={() => setCart(cart + 1)}><Plus size={18} /></button></div></div></article>)}</div></div></section>

        <section className="marquee-dark"><div className="container split-callout"><div><p className="eyebrow">WHY WE SMASH</p><h2>NO SHORTCUTS.<br /><span>JUST FLAVOUR.</span></h2></div><p className="callout-copy">We start with 100% fresh local beef, a screaming hot cast-iron grill and a few minutes to let the magic happen. That&apos;s it. That&apos;s the secret.</p></div></section>

        <section id="full-menu" className="section container menu-section"><div className="section-head"><div><p className="eyebrow dark">THE FULL LINEUP</p><h2>MAKE IT A<br /><span>MEAL.</span></h2></div><div className="cart-note">{cart > 0 ? `${cart} item${cart > 1 ? 's' : ''} ready` : 'Order for pickup or delivery'} <a href={wa}>Start order <ArrowUpRight size={15} /></a></div></div><div className="tabs" role="tablist">{Object.keys(menu).map((item) => <button key={item} className={category === item ? 'selected' : ''} onClick={() => setCategory(item as keyof typeof menu)}>{item}</button>)}</div><div className="menu-list">{menu[category].map(([name, desc, price, badge]) => <div className="menu-row" key={name}><div className="menu-thumb"><img src={category === 'Burgers' ? '/smashed-burger-menu.png' : '/smashed-burger-hero.png'} alt="" /></div><div className="menu-description"><div className="menu-title"><h3>{name}</h3>{badge && <span>{badge}</span>}</div><p>{desc}</p></div><strong className="menu-price">{price}<small> IQD</small></strong><button className="add-button outline" onClick={() => setCart(cart + 1)} aria-label={`Add ${name}`}><Plus size={17} /></button></div>)}</div></section>

        <section id="about" className="about-section"><div className="container about-grid"><div className="about-photo"><img src="/smashed-burger-hero.png" alt="Smashed burger on the grill" /><div className="photo-label">EST. 2024<br /><b>ERBIL</b></div></div><div className="about-copy"><p className="eyebrow dark">OUR STORY</p><h2>THE SMASH<br /><span>MATTERS.</span></h2><p>Smashed Burger started with one obsession: the perfect smash. We hand-press 100% fresh local beef, smash it hard on cast iron, and let the Maillard reaction do the magic.</p><p>No fillers. No shortcuts. Just Erbil&apos;s crispiest, juiciest burger — served fast, served hot, served with pride.</p><blockquote>“Good burgers don&apos;t need explaining.”<cite>— The Smashed Burger crew</cite></blockquote></div></div></section>

        <section id="reviews" className="section container reviews-section"><div className="review-top"><div><p className="eyebrow dark">THE WORD ON THE STREET</p><h2>LOVE AT<br /><span>FIRST BITE.</span></h2></div><div className="rating"><strong>4.9</strong><div><span>★★★★★</span><small>Google rating · 500+ reviews</small></div></div></div><div className="review-grid"><article><div className="stars">★★★★★</div><p>“Honestly the best smash burger I&apos;ve had in Erbil. Crispy edges, perfect sauce, and it arrived hot.”</p><b>— Sara M.</b></article><article><div className="stars">★★★★★</div><p>“The Double Cheese is unreal. Fast service, generous portions, and the team is lovely.”</p><b>— Alan K.</b></article><article><div className="stars">★★★★★</div><p>“Finally a burger place that understands the assignment. The spicy one is addictive.”</p><b>— Dilan R.</b></article></div></section>

        <section id="contact" className="visit-section"><div className="container visit-grid"><div><p className="eyebrow">FIND US IN ERBIL</p><h2>COME<br /><span>HUNGRY.</span></h2><div className="details"><p><MapPin size={18} /><span>Smash&apos;d Burger, Gulan Street<br /><small>The Boulevard, Erbil 44001</small></span></p><p><Clock3 size={18} /><span>Sat–Thu: 11:00 – 00:00<br /><small>Friday: 14:00 – 00:00</small></span></p><p><MessageCircle size={18} /><span>+964 750 000 0000<br /><small>WhatsApp orders welcome</small></span></p></div><a className="button button-orange" href="https://maps.google.com/?q=Smash%27d+Burger,+Gulan+Street,+The+Boulevard,+Erbil,+Iraq">Get directions <ArrowUpRight size={16} /></a></div><div className="map-card"><div className="map-grid"><LocationMap /></div><div className="map-caption">ERBIL, IRAQ <span>OPEN NOW</span></div></div></div></section>
      </main>

      <footer><div className="container footer-grid"><a href="#home" className="brand footer-brand"><span className="brand-mark"><Flame size={19} fill="currentColor" /></span><span>SMASHED<br /><b>BURGER</b></span></a><p>Bold burgers. Big flavour.<br />Made in Erbil.</p><div className="socials"><a href="#contact" aria-label="Instagram">instagram</a><a href="#contact" aria-label="TikTok">tiktok</a><a href="#contact" aria-label="Facebook">f</a></div><div className="copyright">© 2024 Smashed Burger · Designed in Erbil</div></div></footer><a className="whatsapp" href={wa} aria-label="Order on WhatsApp"><MessageCircle size={24} fill="currentColor" /></a>
    </div>
  )
}
